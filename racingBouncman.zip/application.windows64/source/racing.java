import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class racing extends PApplet {

boolean firstFrameClick=true;
Boolean[] keys= new Boolean[14];
Table table;

int gameMode = 0;
float camX=0;
float camY=0;

float time;
Racecar car;
Finish fin;
CheckPoint cp1;
CheckPoint cp2;
CheckPoint cp3;
int cpReached;
Start start;
float startTimer;
float highscore1=0;String scoreHolder1="-";
float highscore2=0;String scoreHolder2="-";
float highscore3=0;String scoreHolder3="-";
String name="";

ArrayList<MapObj> bigMap = new ArrayList<MapObj>();
ArrayList<Wheel> wheels = new ArrayList<Wheel>();

public void setup(){
  
  
  rectMode(CENTER);
  textAlign(CENTER, CENTER);
  frameRate(120);
  imageMode(CENTER);
  loadImg();
  //table= loadTable("new.csv","header,csv");
  
  for(int i=0;i<keys.length;i++){
    keys[i]=false;
  }
  
  nameGen();
}

public void draw(){
  background(255);
  if(gameMode==0){
    textC("name: "+name,960, 350, 30, 0);
    namePad();
    fill(200);
    rect(960, 450, 400, 100);
    textC("start",960, 450, 30, 0);
    if(buttonPressed(960, 450, 400, 100))startGame();
    fill(200);
    rect(960, 600, 400, 100);
    textC("generate map",960, 600, 30, 0);
    if(buttonPressed(960, 600, 400, 100))newMap();
    fill(200);
    rect(960, 750, 400, 100);
    textC("exit",960, 750, 30, 0);
    if(buttonPressed(960, 750, 400, 100))exit();
  }
  
  if(gameMode==1){
    time++;
    fin.draw();
    start.draw();
    if(cpReached==0){
      cp1.draw();
    }
    if(cpReached==1){
      cp2.draw();
    }
    if(cpReached==2){
      cp3.draw();
    }
    for(int i=0;i<bigMap.size();i++){
      bigMap.get(i).draw();
    }
    for(int i=0;i<wheels.size();i++){
      wheels.get(i).draw();
    }
    
    car.draw();
    float camSpeed=distance(0,0,car.speedX,car.speedY)/5;
    if(camSpeed<1)camSpeed=1;
    camX=(camX*43+car.posX-960+(car.speedX/camSpeed*60))/44;
    camY=(camY*43+car.posY-540+(car.speedY/camSpeed*100))/44;
    if(startTimer>0){
      startTimer--;
      textC(""+(int)(1+startTimer/120),960, 500, 30, 0);
    }
  }
  
  if(gameMode==2){
    String timeString =""+time/120;
    if(timeString.length()>6) timeString=timeString.substring(0,5)+"s";
    String hsString1 =""+highscore1/120;
    if(hsString1.length()>6)hsString1=hsString1.substring(0,5)+"s";
    String hsString2 =""+highscore2/120;
    if(hsString2.length()>6)hsString2=hsString2.substring(0,5)+"s";
    String hsString3 =""+highscore3/120;
    if(hsString3.length()>6)hsString3=hsString3.substring(0,5)+"s";
    textC("time: " + timeString,960, 200, 30, 0);
    textC(scoreHolder1+": " + hsString1,360, 200, 30, 0);
    textC(scoreHolder2+": " + hsString2,360, 240, 30, 0);
    textC(scoreHolder3+": " + hsString3,360, 280, 30, 0);
    fill(200);
    rect(960, 450, 400, 100);
    textC("restart",960, 450, 30, 0);
    if(buttonPressed(960, 450, 400, 100))startGame();
    fill(200);
    rect(960, 600, 400, 100);
    textC("back",960, 600, 30, 0);
    if(buttonPressed(960, 600, 400, 100))gameMode=0;
  }
  
  if (!keyPressed && !mousePressed)firstFrameClick=true;
  if (keyPressed || mousePressed )firstFrameClick=false;
}


public void startGame(){
  gameMode=1;
  time=0;
  cpReached=1;
  
  loadMap();
  car=new Racecar();
  camX=car.posX-960;
  camY=car.posY-540;
  fin=new Finish();
  start=new Start();
  startTimer=3*120;
}

public void newMap(){
  bigMap.clear();
  wheels.clear();
  highscore1=0;scoreHolder1="-";
  highscore2=0;scoreHolder2="-";
  highscore3=0;scoreHolder3="-";
  int r=(int)random(160);
  
  for(int i=0;i<1500;i++){
    bigMap.add(new MapObj());
  }
  
  r=(int)random(250);
  for(int i=0;i<r;i++){
    bigMap.add(new Ice());
  }
  r=(int)random(150);
  for(int i=0;i<r;i++){
    bigMap.add(new Mud());
  }
  r=(int)random(60);
  for(int i=0;i<r;i++){
    bigMap.add(new Road());
  }
  
  r=(int)random(50);
  for(int i=0;i<r;i++){
    bigMap.add(new Conveyer());
  }
  
  
  r=(int)random(200);
  for(int i=0;i<r;i++){
    bigMap.add(new Polster());
  }
  
  r=(int)random(300);
  for(int i=0;i<r;i++){
    bigMap.add(new Trampo());
  }
  
  r=150+(int)random(400);
  for(int i=0;i<r;i++){
    bigMap.add(new Stop());
  }
  
  r=25+(int)random(40);
  for(int i=0;i<r;i++){
    bigMap.add(new Nitro());
  }
  r=10+(int)random(20);
  for(int i=0;i<r;i++){
    bigMap.add(new BigNitro());
  }
  
  r=15+(int)random(40);
  for(int i=0;i<r;i++){
    bigMap.add(new Boost());
  }
  
  r=160+(int)random(600);
  for(int i=0;i<r;i++){
    wheels.add(new Wheel());
  }
  
  cp1=new CheckPoint();
  cp2=new CheckPoint();
  cp3=new CheckPoint();
  save();
}

public void setHighscore(){
  if(time<highscore1 || highscore1==0){
    highscore3=highscore2;
    scoreHolder3=scoreHolder2;
    highscore2=highscore1;
    scoreHolder2=scoreHolder1;
    highscore1=time;
    scoreHolder1=name;
  }else{
    if(time<highscore2 || highscore2==0){
      highscore3=highscore2;
      scoreHolder3=scoreHolder2;
      highscore2=time;
      scoreHolder2=name;
    }else{
      if(time<highscore3 || highscore3==0){
        highscore3=time;
        scoreHolder3=name;
      }
    }
  }
  saveHighscores();
}

public void deletUnderme(float posX,float posY,float size){
  
  for(int i=0;i<bigMap.size();i++){
    if(distance(posX,posY,bigMap.get(i).posX,bigMap.get(i).posY)<size/2+bigMap.get(i).size/2){
      bigMap.remove(bigMap.get(i));
      i--;
    }
  }
}

public void namePad(){
  if(keyPressed && firstFrameClick){
    if(key=='a' || key=='A')name = name+"A";
    if(key=='b' || key=='B')name = name+"B";
    if(key=='c' || key=='C')name = name+"C";
    if(key=='d' || key=='D')name = name+"D";
    if(key=='e' || key=='E')name = name+"E";
    if(key=='f' || key=='F')name = name+"F";
    if(key=='g' || key=='G')name = name+"G";
    if(key=='h' || key=='H')name = name+"H";
    if(key=='i' || key=='I')name = name+"I";
    if(key=='j' || key=='J')name = name+"J";
    if(key=='k' || key=='K')name = name+"K";
    if(key=='l' || key=='L')name = name+"L";
    if(key=='m' || key=='M')name = name+"M";
    if(key=='n' || key=='N')name = name+"N";
    if(key=='o' || key=='O')name = name+"O";
    if(key=='p' || key=='P')name = name+"P";
    if(key=='q' || key=='Q')name = name+"Q";
    if(key=='r' || key=='R')name = name+"R";
    if(key=='s' || key=='S')name = name+"S";
    if(key=='t' || key=='T')name = name+"T";
    if(key=='u' || key=='U')name = name+"U";
    if(key=='v' || key=='V')name = name+"V";
    if(key=='w' || key=='W')name = name+"W";
    if(key=='x' || key=='X')name = name+"X";
    if(key=='y' || key=='Y')name = name+"Y";
    if(key=='z' || key=='Z')name = name+"Z";
    if(key==' ')name = name+" ";
    if(key=='-')name = name+"-";
    if(key==BACKSPACE && name.length()>0)name = name.substring(0,name.length()-1);
    if(name.length()>12)name = name.substring(0,12);
  }
}
class Finish{
  
  float posX = 13000;
  float posY = 13000;
  float size = 400;
  
  Finish(){
    for(int i=0;i<bigMap.size();i++){
      if(distance(posX,posY,bigMap.get(i).posX,bigMap.get(i).posY)<size){
        bigMap.remove(bigMap.get(i));
        i--;
      }
    }
    
    for(int i=0;i<wheels.size();i++){
      if(distance(posX,posY,wheels.get(i).posX,wheels.get(i).posY)<size){
        wheels.remove(wheels.get(i));
        i--;
      }
    }
  }
  
  public void draw(){
    imageD(checkI,posX,posY,size*2);
    fill(0);
    //ellipseD(posX,posY,size);
    if(distance(car.posX,car.posY,posX,posY)<size/2 && cpReached>=3){
      gameMode=2;
      setHighscore();
    }
  }
}

class Start{
  
  float posX = 2000;
  float posY = 2000;
  float size = 600; 
  
  Start(){
    for(int i=0;i<bigMap.size();i++){
      if(distance(posX,posY,bigMap.get(i).posX,bigMap.get(i).posY)<size){
        bigMap.remove(bigMap.get(i));
        i--;
      }
    }
    
    for(int i=0;i<wheels.size();i++){
      if(distance(posX,posY,wheels.get(i).posX,wheels.get(i).posY)<size){
        wheels.remove(wheels.get(i));
        i--;
      }
    }
  }
  
  public void draw(){
    //imageD(floorI,posX,posY,size*2);
    fill(255);
    ellipseD(posX,posY,size);
  }
}

class CheckPoint{
  
  float posX = 2000+random(11000);
  float posY = 2000+random(11000);
  float size = 300;
  
  CheckPoint(){
    for(int i=0;i<bigMap.size();i++){
      if(distance(posX,posY,bigMap.get(i).posX,bigMap.get(i).posY)<size){
        bigMap.remove(bigMap.get(i));
        i--;
      }
    }
    
    for(int i=0;i<wheels.size();i++){
      if(distance(posX,posY,wheels.get(i).posX,wheels.get(i).posY)<size){
        wheels.remove(wheels.get(i));
        i--;
      }
    }
  }
  
  CheckPoint(float posX, float posY){
    this.posX=posX;
    this.posY=posY;
    for(int i=0;i<bigMap.size();i++){
      if(distance(posX,posY,bigMap.get(i).posX,bigMap.get(i).posY)<size){
        bigMap.remove(bigMap.get(i));
        i--;
      }
    }
    
    for(int i=0;i<wheels.size();i++){
      if(distance(posX,posY,wheels.get(i).posX,wheels.get(i).posY)<size){
        wheels.remove(wheels.get(i));
        i--;
      }
    }
  }
  
  public void draw(){
    imageD(checkI,posX,posY,size*2);
    fill(0);
    //ellipseD(posX,posY,size);
    if(distance(car.posX,car.posY,posX,posY)<size/2){
      cpReached++;
    }
  }
}
PImage carI;
PImage floorI;
PImage arrowFinI;
PImage reifnI;
PImage iceI;
PImage stopI;
PImage checkI;
PImage nitroI;
PImage bignitroI;
PImage trampoI;
PImage mudI;
PImage roadI;
PImage converyerI;
PImage boostI;
PImage polsterI;


public void loadImg(){
  carI = loadImage("car.png");
  arrowFinI = loadImage("arrow.png");
  floorI = loadImage("Floor.png");
  reifnI = loadImage("reifn.png");
  iceI = loadImage("ice.png");
  stopI = loadImage("stop.png");
  checkI = loadImage("checkpoint.png");
  nitroI = loadImage("nitro.png");
  bignitroI = loadImage("bignitro.png");
  trampoI = loadImage("trampolin.png");
  roadI = loadImage("road.png");
  mudI = loadImage("mud.png");
  converyerI = loadImage("converyer.png");
  boostI = loadImage("boost.png");
  polsterI = loadImage("polster.png");
}

public void save(){
  table= loadTable("new.csv","header,csv");
  int objects=bigMap.size()+wheels.size();
  table.getRow(0).setFloat("value",objects);
  
  for(int i=0;i<bigMap.size();i++){
    table.getRow(i+1).setFloat("value",bigMap.get(i).code);
    table.getRow(i+1).setFloat("posX",bigMap.get(i).posX);
    table.getRow(i+1).setFloat("posY",bigMap.get(i).posY);
    table.getRow(i+1).setFloat("size",bigMap.get(i).size);
    table.getRow(i+1).setFloat("angle",bigMap.get(i).angle);
  }
  
  for(int i=0;i<wheels.size();i++){
    table.getRow(i+1+bigMap.size()).setFloat("value",wheels.get(i).code);
    table.getRow(i+1+bigMap.size()).setFloat("posX",wheels.get(i).posX);
    table.getRow(i+1+bigMap.size()).setFloat("posY",wheels.get(i).posY);
    table.getRow(i+1+bigMap.size()).setFloat("size",wheels.get(i).size);
  }
  table.getRow(wheels.size()+1+bigMap.size()).setFloat("posX",cp1.posX);
  table.getRow(wheels.size()+1+bigMap.size()).setFloat("posY",cp1.posY);
  table.getRow(wheels.size()+2+bigMap.size()).setFloat("posX",cp2.posX);
  table.getRow(wheels.size()+2+bigMap.size()).setFloat("posY",cp2.posY);
  table.getRow(wheels.size()+3+bigMap.size()).setFloat("posX",cp3.posX);
  table.getRow(wheels.size()+3+bigMap.size()).setFloat("posY",cp3.posY);
  
  saveTable(table, "data/new.csv");
  
  saveHighscores();
}

public void saveHighscores(){
  table= loadTable("new.csv","header,csv");
  int objects=(int)table.getFloat(0,"value");
  table.getRow(objects+4).setFloat("value",highscore1);
  table.getRow(objects+4).setString("name",scoreHolder1);
  table.getRow(objects+5).setFloat("value",highscore2);
  table.getRow(objects+5).setString("name",scoreHolder2);
  table.getRow(objects+6).setFloat("value",highscore3);
  table.getRow(objects+6).setString("name",scoreHolder3);
  saveTable(table, "data/new.csv");
}

public void loadMap(){
  table= loadTable("new.csv","header,csv");
  bigMap.clear();
  wheels.clear();
  int objects=(int)table.getFloat(0,"value");
  
  for(int i=1;i<objects+1;i++){
    switch ((int)table.getFloat(i,"value")){
      case -1:
        bigMap.add( new MapObj());
        break;
      case 0:
        wheels.add( new Wheel(table.getFloat(i,"posX"),table.getFloat(i,"posY"),table.getFloat(i,"size"),false) );
        break;
      case 1:
        bigMap.add( new Ice(table.getFloat(i,"posX"),table.getFloat(i,"posY"),table.getFloat(i,"size"),false) );
        break;
      case 2:
        bigMap.add( new Stop(table.getFloat(i,"posX"),table.getFloat(i,"posY"),table.getFloat(i,"size"),false) );
        break;
      case 3:
        bigMap.add( new Nitro(table.getFloat(i,"posX"),table.getFloat(i,"posY"),table.getFloat(i,"size"),false) );
        break;
      case 4:
        bigMap.add( new Trampo(table.getFloat(i,"posX"),table.getFloat(i,"posY"),table.getFloat(i,"size"),false) );
        break;
      case 5:
        bigMap.add( new Mud(table.getFloat(i,"posX"),table.getFloat(i,"posY"),table.getFloat(i,"size"),false) );
        break;
      case 6:
        bigMap.add( new Road(table.getFloat(i,"posX"),table.getFloat(i,"posY"),table.getFloat(i,"size"),table.getFloat(i,"angle"),false) );
        break;
      case 7:
        bigMap.add( new BigNitro(table.getFloat(i,"posX"),table.getFloat(i,"posY"),table.getFloat(i,"size"),false) );
        break;
      case 8:
        bigMap.add( new Conveyer(table.getFloat(i,"posX"),table.getFloat(i,"posY"),table.getFloat(i,"size"),table.getFloat(i,"angle"),false) );
        break;
      case 9:
        bigMap.add( new Boost(table.getFloat(i,"posX"),table.getFloat(i,"posY"),table.getFloat(i,"size"),table.getFloat(i,"angle"),false) );
        break;
      case 10:
        bigMap.add( new Polster(table.getFloat(i,"posX"),table.getFloat(i,"posY"),table.getFloat(i,"size"),table.getFloat(i,"angle"),false) );
        break;
    }
  }
  cp1=new CheckPoint(table.getFloat(objects+1,"posX"),table.getFloat(objects+1,"posY"));
  cp2=new CheckPoint(table.getFloat(objects+2,"posX"),table.getFloat(objects+2,"posY"));
  cp3=new CheckPoint(table.getFloat(objects+3,"posX"),table.getFloat(objects+3,"posY"));
  
  highscore1=table.getFloat(objects+4,"value");
  scoreHolder1=table.getString(objects+4,"name");
  highscore2=table.getFloat(objects+5,"value");
  scoreHolder2=table.getString(objects+5,"name");
  highscore3=table.getFloat(objects+6,"value");
  scoreHolder3=table.getString(objects+6,"name");
}
class MapObj{
  
  float posX = random(15000);
  float posY = random(15000);
  float size = 100;
  float angle=0;
  float code=-1;
  
  public void draw(){
    imageD(floorI,posX,posY,size);
  }
}

class Wheel extends MapObj{
  
  float speedX;
  float speedY;
  
  Wheel(){
    code=0;
    size = random(30,100);
    if(random(100)<35){
      float angle=random(TWO_PI);
      float dist = size/2;
      bigMap.add(new Wheel( posX +dist*cos(angle), posY +dist*sin(angle),angle));
    }
  }
  
  Wheel(float posX,float posY, float dir){
    code=0;
    size = random(30,100);
    this.posX=posX+size/2*cos(dir);
    this.posY=posY+size/2*sin(dir);
    if(random(100)<85){
      float angle=dir+random(-HALF_PI/2,HALF_PI/2);
      float dist = size;
      bigMap.add(new Wheel( posX +dist*cos(angle), posY +dist*sin(angle),angle));
    }
  }
  Wheel(float posX,float posY, float size,boolean b){
    code=0;
    this.size=size;
    this.posX=posX;
    this.posY=posY;
  }
  
  public void draw(){
    imageD(reifnI,posX,posY,size*2);
    
    if(distance(posX,posY,car.posX,car.posY)<size/2+car.size/2 && car.posZ<=0){
      float speed=(float)Math.pow(0.7f,0.7f+size/140)  *2*distance(0,0,car.speedX,car.speedY);
      speedX=speed*(posX-car.posX)/distance(posX,posY,car.posX,car.posY);
      speedY=speed*(posY-car.posY)/distance(posX,posY,car.posX,car.posY);
      car.speedX*=  Math.pow(0.7f,0.7f+size/140);
      car.speedY*=  Math.pow(0.7f,0.7f+size/140);
    }
    speedX*=0.995f;
    speedY*=0.995f;
    posX+=speedX;
    posY+=speedY;
  }
}

class Ice extends MapObj{
  
  Ice(){
    code=1;
    size = random(200,400);
  }
  Ice(float posX,float posY, float size,boolean b){
    code=1;
    this.size=size;
    this.posX=posX;
    this.posY=posY;
  }
  
  public void draw(){
    imageD(iceI,posX,posY,size*2);
    
    if(distance(posX,posY,car.posX,car.posY)<size/2+car.size/2 && car.posZ<=0){
      car.drift=100;
    }
  }
}

class Stop extends MapObj{
  
  Stop(){
    code=2;
    size = random(50,200);
    deletUnderme(this.posX,this.posY,size);
    if(random(100)<35){
      float angle=random(TWO_PI);
      float dist = size/2;
      bigMap.add(new Stop( posX +dist*cos(angle), posY +dist*sin(angle),angle));
    }
  }
  
  Stop(float posX,float posY, float dir){
    code=2;
    size = random(50,200);
    this.posX=posX+size/2*cos(dir);
    this.posY=posY+size/2*sin(dir);
    deletUnderme(this.posX,this.posY,size);
    if(random(100)<80){
      float angle=dir+random(-HALF_PI/2,HALF_PI/2);
      float dist = size;
      bigMap.add(new Stop( posX +dist*cos(angle), posY +dist*sin(angle),angle));
    }
  }
  Stop(float posX,float posY, float size,boolean b){
    code=2;
    this.size=size;
    this.posX=posX;
    this.posY=posY;
  }
  
  public void draw(){
    imageD(stopI,posX,posY,size*2);
    
    if(distance(posX,posY,car.posX,car.posY)<size/2+car.size/2 && car.posZ<=0){
      startGame();
    }
  }
}

class Nitro extends MapObj{
  
  Nitro(){
    code=3;
    size = 80;
  }
  Nitro(float posX,float posY, float size,boolean b){
    code=3;
    this.size=size;
    this.posX=posX;
    this.posY=posY;
  }
  
  public void draw(){
    imageD(nitroI,posX,posY,size*2);
    
    if(distance(posX,posY,car.posX,car.posY)<size/2+car.size/2 && car.posZ<=0){
      car.nitro+=90;
      bigMap.remove(this);
    }
  }
}

class Trampo extends MapObj{
  
  Trampo(){
    code=4;
    size = 110;
    deletUnderme(this.posX,this.posY,size);
  }
  Trampo(float posX,float posY, float size,boolean b){
    code=4;
    this.size=size;
    this.posX=posX;
    this.posY=posY;
  }
  
  public void draw(){
    imageD(trampoI,posX,posY,size*2);
    
    if(distance(posX,posY,car.posX,car.posY)<size/2+car.size/2 && car.posZ<=0){
      car.speedZ=car.currentSpeed*0.6f;
    }
  }
}

class Mud extends MapObj{
  
  Mud(){
    code=5;
    size = random(300,400);
    deletUnderme(this.posX,this.posY,size);
    if(random(100)<50){
      float angle=random(TWO_PI);
      float dist = size/2;
      bigMap.add(new Mud( posX +dist*cos(angle), posY +dist*sin(angle),angle));
    }
  }
  
  Mud(float posX,float posY, float dir){
    code=5;
    size = random(50,150);
    this.posX=posX+size/2*cos(dir);
    this.posY=posY+size/2*sin(dir);
    deletUnderme(this.posX,this.posY,size);
    if(random(100)<10){
      float angle=dir+random(-HALF_PI/2,HALF_PI/2);
      float dist = size;
      bigMap.add(new Mud( posX +dist*cos(angle), posY +dist*sin(angle),angle));
    }
  }
  Mud(float posX,float posY, float size,boolean b){
    code=5;
    this.size=size;
    this.posX=posX;
    this.posY=posY;
  }
  
  public void draw(){
    imageD(mudI,posX,posY,size*2);
    
    if(distance(posX,posY,car.posX,car.posY)<size/2+car.size/2 && car.posZ<=0){
      car.drift=50;
      car.speed=3;
    }
  }
}

class Road extends MapObj{
  
  Road(){
    code=6;
    size = 180;
    angle=random(TWO_PI);
    if(random(100)<100){  
      float dist = 75;
      bigMap.add(new Road( posX +dist*cos(angle), posY +dist*sin(angle),angle));
    }
  }
  Road(float posX,float posY, float dir){
    code=6;
    size = 180;
    this.posX=posX+size/2*cos(dir);
    this.posY=posY+size/2*sin(dir);
    angle=dir+random(-HALF_PI/2,HALF_PI/2);
    if(random(100)<90){
      float dist = 150;
      bigMap.add(new Road( posX +dist*cos(angle), posY +dist*sin(angle),angle));
    }
  }
  Road(float posX,float posY, float size,float angle,boolean b){
    code=6;
    this.size=size;
    this.posX=posX;
    this.posY=posY;
    this.angle=angle;
  }
  
  public void draw(){
    turnImgD(roadI,posX,posY,size*2,size*2,angle);
    
    if(distance(posX,posY,car.posX,car.posY)<size/2+car.size/2 && car.posZ<=0){
      car.drift=3;
    }
  }
}

class BigNitro extends MapObj{
  
  BigNitro(){
    code=7;
    size = 120;
  }
  BigNitro(float posX,float posY, float size,boolean b){
    code=7;
    this.size=size;
    this.posX=posX;
    this.posY=posY;
  }
  
  public void draw(){
    imageD(bignitroI,posX,posY,size*2);
    
    if(distance(posX,posY,car.posX,car.posY)<size/2+car.size/2 && car.posZ<=0){
      car.nitro+=180;
      car.speedX*=1.1f;
      car.speedY*=1.1f;
      bigMap.remove(this);
    }
  }
}


class Conveyer extends MapObj{
  float speed=1.1f;
  Conveyer(){
    code=8;
    size = 160;
    deletUnderme(posX,posY,size);
    if(random(100)<100){
      angle=HALF_PI*(int)random(4);
      float dist = size/2;
      bigMap.add(new Conveyer( posX +dist*cos(angle), posY +dist*sin(angle),angle));
    }
  }
  Conveyer(float posX,float posY, float dir){
    code=8;
    size = 160; 
    this.posX=posX+size/2*cos(dir);
    this.posY=posY+size/2*sin(dir);
    deletUnderme(this.posX,this.posY,size);
    this.angle=dir;
    if(random(100)<90){
      float dist = size;
      bigMap.add(new Conveyer( posX +dist*cos(angle), posY +dist*sin(angle),angle));
    }
  }
  Conveyer(float posX,float posY, float size,float angle,boolean b){
    code=8;
    this.size=size;
    this.posX=posX;
    this.posY=posY;
    this.angle=angle;
  }
  
  public void draw(){
    turnImgD(converyerI,posX,posY,size*2,size*2,angle);
    
    if(car.posX<posX+size/2 && car.posX>posX-size/2 && car.posY<posY+size/2 && car.posY>posY-size/2 && car.posZ<=0){
      car.posX+=speed*cos(angle);
      car.posY+=speed*sin(angle);
    }
  }
}

class Boost extends MapObj{
  float speed=6;
  Boost(){
    code=9;
    size = 120;
    angle=random(TWO_PI);
  }
  Boost(float posX,float posY, float size,float angle,boolean b){
    code=9;
    this.size=size;
    this.posX=posX;
    this.posY=posY;
    this.angle=angle;
  }
  
  public void draw(){
    turnImgD(boostI,posX,posY,size*2,size*2,angle);
    
    if(distance(posX,posY,car.posX,car.posY)<size/2+car.size/2 && car.posZ<=0){
      car.speedX+=speed*cos(angle);
      car.speedY+=speed*sin(angle);
      car.speedZ=speed/2;
      bigMap.remove(this);
    }
  }
}

class Polster extends MapObj{
  Polster(){
    code=10;
    size = 160;
  }
  Polster(float posX,float posY, float size,float angle,boolean b){
    code=10;
    this.size=size;
    this.posX=posX;
    this.posY=posY;
    this.angle=angle;
  }
  
  public void draw(){
    turnImgD(polsterI,posX,posY,size*2,size*2,angle);
    
    if(distance(posX,posY,car.posX,car.posY)<size/2+car.size/2 && car.posZ<=0){
      float speedX=car.posX-posX;
      float speedY=car.posY-posY;
      float dis=distance(0,0,speedX,speedY);
      car.speedX+=2*car.currentSpeed*speedX/dis;
      car.speedY+=2*car.currentSpeed*speedY/dis;
      car.posX+=car.speedX;
      car.posY+=car.speedY;
      car.speedZ=car.currentSpeed*0.3f;
      
      /*float CF= ((car.speedX)*(posX-car.posX)+(car.speedY)*(posY-car.posY)) / (float)(Math.pow(car.speedX,2)+Math.pow(car.speedY,2)) ;
      float bonceX=car.posX+ (car.speedX)*CF-posX;
      float bonceY=car.posY+ (car.speedY)*CF-posY;
      print(CF);
      car.speedX+=0.2*bonceX;
      car.speedY+=0.2*bonceY;
      car.posX+=car.speedX;
      car.posY+=car.speedY;
      car.speedZ=1;*/
    }
  }
}
class Racecar{
  float posX = 2000;
  float posY = 2000;
  float size = 30;
  float speedX;
  float speedY;
  float speed=0;
  float beschln = 1;
  float drift;
  float grip;
  float nitro;
  float angle;
  float turnSpeed = 0.035f;
  float angleChange;
  float speedZ;
  float posZ;
  float currentSpeed;
  float convMode=-1;
  
  public void draw(){
    if(keys[6] && nitro>0){
      //speed*=2;
      nitro--;
      beschln+=25.0f/120*(3-beschln);
    }
    if(nitro>0){
      fill(0xffD7FF5F);
      rect(50,1030+(-nitro)/2,40,nitro);
    }
    if(posZ<=0) drive2();
    else turnImgD(carI,posX,posY-posZ*0.65f,size*2,size*2,HALF_PI+angle);
    if(distance(0,0,speedX,speedY)>1){
      if(keys[1])angle-=turnSpeed;
      if(keys[3])angle+=turnSpeed;
    }
    if(cpReached==0){
      turnImgD(arrowFinI,posX,posY,size*2,size*2,HALF_PI+angle(posX, posY,cp1.posX,cp1.posY));
    }
    if(cpReached==1){
      turnImgD(arrowFinI,posX,posY,size*2,size*2,HALF_PI+angle(posX, posY,cp2.posX,cp2.posY));
    }
    if(cpReached==2){
      turnImgD(arrowFinI,posX,posY,size*2,size*2,HALF_PI+angle(posX, posY,cp3.posX,cp3.posY));
    }
    if(cpReached==3){
      turnImgD(arrowFinI,posX,posY,size*2,size*2,HALF_PI+angle(posX, posY,fin.posX,fin.posY));
    }


    posX=posX+speedX;
    posY=posY+speedY;
    speedZ-=10.0f/120;
    posZ=posZ+speedZ;
    if(posZ<0){
      posZ=0;
      speedZ=0;
    }
    
    baseStat();
  }
  
  public void drive1(){
    if(keys[0] || keys[12]){
      float dist = distance(mouseX+camX,mouseY+camY, posX,posY);
      speedX = (speedX*drift + beschln*speed*(mouseX+camX-posX)/dist )/(drift+1);
      speedY = (speedY*drift + beschln*speed*(mouseY+camY-posY)/dist )/(drift+1);
      if(distance(0,0,speedX,speedY)>0.95f*speed*beschln) beschln+=0.1f/120;
      else beschln=1;
      turnImgD(carI,posX,posY,size*2,size*2,HALF_PI+angle(posX, posY,mouseX+camX,mouseY+camY));
    }else{
      turnImgD(carI,posX,posY,size*2,size*2,HALF_PI+angle(posX, posY,mouseX+camX,mouseY+camY));
      speedX=speedX*grip;
      speedY=speedY*grip;
    }
    if(keys[2] || keys[13]){
      speedX=speedX*0.95f;
      speedY=speedY*0.95f;
    }
  }
  
  public void drive2(){
    currentSpeed=distance(0,0,speedX,speedY);
    if(keys[0] || keys[12]){
      /*float angMouse = (angle(posX,posY,mouseX+camX,mouseY+camY)+TWO_PI)%TWO_PI;
      textC(""+angMouse,960, 600, 30, 0);
      textC(""+angle,960, 700, 30, 0);
      if(Math.abs(angMouse-angle) <= turnSpeed )angle=angMouse;
      else if(Math.abs(angMouse-angle) < Math.abs(TWO_PI-(angMouse-angle)))angle+=turnSpeed;
      else angle-=turnSpeed;
      angle=(angle+TWO_PI)%TWO_PI; */
      
      speedX = (speedX*(currentSpeed+drift) + beschln*speed*cos(angle) )/(drift+currentSpeed+1);
      speedY = (speedY*(currentSpeed+drift) + beschln*speed*sin(angle) )/(drift+currentSpeed+1);
      if( distance(0,0,speedX,speedY)>0.95f*speed*beschln) beschln+=0.3f/120*(2-beschln);
      else beschln-=0.3f;
      if(beschln<1)beschln=1;
      turnImgD(carI,posX,posY,size*2,size*2,HALF_PI+angle);
    }else{
      turnImgD(carI,posX,posY,size*2,size*2,HALF_PI+angle);
      speedX = (speedX*(currentSpeed+drift) + grip*currentSpeed*cos(angle) )/(drift+currentSpeed+1);
      speedY = (speedY*(currentSpeed+drift) + grip*currentSpeed*sin(angle) )/(drift+currentSpeed+1);
    }
    if(keys[2] || keys[13]){
      speedX = (speedX*drift)/(drift+1);
      speedY = (speedY*drift)/(drift+1);
      if(distance(0,0,speedX,speedY)>0.95f*speed*beschln) beschln+=0.1f/120;
      else beschln=1;
    }
  }
  
  public void baseStat(){
    if(startTimer<=0)speed=3.5f;
    else speed=0;
    drift = 16;
    grip = 0.95f;
  }
}
public boolean buttonPressed(float posX, float posY, float sizeX, float sizeY) {
  if (keys[12] && firstFrameClick && mouseX<posX+sizeX/2 && mouseX>posX-sizeX/2 && mouseY<posY+sizeY/2 && mouseY>posY-sizeY/2) {
    return true;
  }
  return false;
}

public boolean buttonRightClick(float posX, float posY, float sizeX, float sizeY) {
  if (keys[13] && mouseX<posX+sizeX/2 && mouseX>posX-sizeX/2 && mouseY<posY+sizeY/2 && mouseY>posY-sizeY/2) {
    return true;
  }
  return false;
}

public boolean buttonHold(float posX, float posY, float sizeX, float sizeY) {
  if (mousePressed && mouseX<posX+sizeX/2 && mouseX>posX-sizeX/2 && mouseY<posY+sizeY/2 && mouseY>posY-sizeY/2) {
    return true;
  }
  return false;
}

public void turnImg(PImage img,float x,float y,float sizeX,float sizeY,float degr){
  pushMatrix();
  translate(x,y);
  rotate(degr);
  image(img,0,0,sizeX,sizeY);
  popMatrix();
}

public void turnImgD(PImage img,float x,float y,float sizeX,float sizeY,float degr){
  pushMatrix();
  translate(x-camX,y-camY);
  rotate(degr);
  image(img,0,0,sizeX,sizeY);
  popMatrix();
}

public void turnFlipImgD(PImage img,float x,float y,float sizeX,float sizeY,float degr){
  pushMatrix();
  translate(x-camX,y-camY);
  if(degr>=HALF_PI || degr<=-HALF_PI){
    scale(-1,1);
    degr=PI-degr;
  }
  rotate(degr);
  image(img,0,0,sizeX,sizeY);
  popMatrix();
}
public void ellipseD(float posX, float posY, float size) {
  ellipse(posX-camX, posY-camY, size, size);
}

public void imageD(PImage img,float posX, float posY, float size) {
  image(img, posX-camX, posY-camY, size, size);
}

public void rectD(float posX, float posY, float size) {
  rect(posX-camX, posY-camY, size, size);
}

public void rectD(float posX, float posY, float sizeX,float sizeY) {
  rect(posX-camX, posY-camY, sizeX, sizeY);
}

public void textC(String text,float x,float y, float size, int c){
  textSize(size);
  fill(c);
  text(text,x,y);
}

public float w(){
  return width/1000.0f;
}
public float h(){
  return height/800.0f;
}

public float distance(float x1, float y1, float x2, float y2) {
  float distance=(float)Math.sqrt(Math.pow(x1-x2, 2)+Math.pow(y1-y2, 2));
  return distance;
}

public float angle(float x1, float y1, float x2, float y2){
  float angle=0;
  angle=(float)Math.atan2( (y2-y1), (x2-x1));
  /*if(x1>x2)angle=TWO_PI-angle;
  if(x2-x1<=1 && x2-x1>=-1){
    if(y1<y2)angle=HALF_PI;
    if(y1>y2)angle=TWO_PI-HALF_PI;
  }
  */
  return angle;
}

public float getPosX(float r,float size){
  if(r<1200){
      return r;
    }else if(r<2400){
      return r-1200;
    }else if(r<3400){
      return -size;
    }else if(r<4400){
      return 1200+size;
    }
    return 0;
}
public float getPosY(float r,float size){
  if(r<1200){
      return -size;
    }else if(r<2400){
      return 1000+size;
    }else if(r<3400){
      return r-2400;
    }else if(r<4400){
      return r-3400;
    }
    return 0;
}
public float getSpeedX(float r,float speed){
  if(r<1200){
      return random(-speed,speed);
    }else if(r<2400){
      return random(-speed,speed);
    }else if(r<3400){
      return random(speed/4,speed);
    }else if(r<4400){
      return random(-speed/4,-speed);
    }
    return 10;
}
public float getSpeedY(float r,float speed){
  if(r<1200){
      return random(speed/4,speed);
    }else if(r<2400){
      return random(-speed/4,-speed);
    }else if(r<3400){
      return random(-speed,speed);
    }else if(r<4400){
      return random(-speed,speed);
    }
    return 10;
}


public void keyPressed() {
  if (key=='w'||key=='W')keys[0]=true;
  if (key=='a'||key=='A')keys[1]=true;
  if (key=='s'||key=='S')keys[2]=true;
  if (key=='d'||key=='D')keys[3]=true;
  if (key=='q'||key=='Q')keys[4]=true;
  if (key=='e'||key=='E')keys[5]=true;
  if (key==' ')          keys[6]=true;
  if (key=='p'||key=='P')keys[7]=true;
  if (key=='m'||key=='M')keys[8]=true;
  if (key=='r'||key=='R')keys[9]=true;
  if (key==ESC) {
    key=0;
    gameMode=0;
  }
  if (key==TAB) {
    key=0;
    keys[11]=true;
  }
}

public void mousePressed() {
  if (mouseButton==LEFT)keys[12]=true;
  if (mouseButton==RIGHT)keys[13]=true;
}

public void keyReleased() {
  if (key=='w'||key=='W')keys[0]=false;
  if (key=='a'||key=='A')keys[1]=false;
  if (key=='s'||key=='S')keys[2]=false;
  if (key=='d'||key=='D')keys[3]=false;
  if (key=='q'||key=='Q')keys[4]=false;
  if (key=='e'||key=='E')keys[5]=false;
  if (key==' ')          keys[6]=false;
  if (key=='p'||key=='P')keys[7]=false;
  if (key=='m'||key=='M')keys[8]=false;
  if (key=='r'||key=='R')keys[9]=false;
  if (key==TAB) {
    key=0;
    keys[11]=false;
  }
}

public void mouseReleased() {
  if (mouseButton==LEFT)keys[12]=false;
  if (mouseButton==RIGHT)keys[13]=false;
}
public void nameGen(){
  
  int r=(int)random(41);
    switch (r){
      case 0:
        name+="MASTER ";
        break;
      case 1:
        name+="LIL ";
        break;
      case 2:
        name+="SIR ";
        break;
      case 3:
        name+="LADY ";
        break;
      case 4:
        name+="DARK ";
        break;
      case 5:
        name+="BAD ";
        break;
      case 6:
        name+="X-";
        break;
      case 7:
        name+="";
        break;
      case 8:
        name+="CANDY-";
        break;
      case 9:
        name+="WHITE ";
        break;
      case 10:
        name+="EVIL ";
        break;
      case 11:
        name+="CHAOTIC ";
        break;
      case 12:
        name+="BABY ";
        break;
      case 13:
        name+="BLIND ";
        break;
      case 14:
        name+="CRAZY ";
        break;
      case 15:
        name+="LIGHTNING ";
        break;
      case 16:
        name+="SPEEDY ";
        break;
      case 17:
        name+="FIRE ";
        break;
      case 18:
        name+="SONIC ";
        break;
      case 19:
        name+="G-";
        break;
      case 20:
        name+="FAST ";
        break;
      case 21:
        name+="GIGA ";
        break;
      case 22:
        name+="TURBO ";
        break;
      case 23:
        name+="MECHA ";
        break;
      case 24:
        name+="GOLDEN ";
        break;
      case 25:
        name+="MASKED ";
        break;
      case 26:
        name+="TIGER ";
        break;
      case 27:
        name+="SHARK ";
        break;
      case 28:
        name+="EPIC ";
        break;
      case 29:
        name+="LAZER ";
        break;
      case 30:
        name+="DUMB ";
        break;
      case 31:
        name+="DEAD ";
        break;
      case 32:
        name+="GHOST ";
        break;
      case 33:
        name+="BIG ";
        break;
      case 34:
        name+="ALIEN ";
        break;
      case 35:
        name+="SHADOW ";
        break;
      case 36:
        name+="PENIS ";
        break;
      case 37:
        name+="BLOOD ";
        break;
      case 39:
        name+="SLIME ";
        break;
      case 40:
        name+="FUTURE ";
        break;
    }
  
  
   r=(int)random(42);
    switch (r){
      case 0:
        name+="NINJA";
        break;
      case 1:
        name+="BOY";
        break;
      case 2:
        name+="GIRL";
        break;
      case 3:
        name+="APE";
        break;
      case 4:
        name+="BRAIN";
        break;
      case 5:
        name+="RACER";
        break;
      case 6:
        name+="KING";
        break;
      case 7:
        name+="QUEEN";
        break;
      case 8:
        name+="BOLT";
        break;
      case 9:
        name+="FEATHER";
        break;
      case 10:
        name+="LORD";
        break;
      case 11:
        name+="HERBERT ";
        break;
      case 12:
        name+="SNIPER";
        break;
      case 13:
        name+="GOD";
        break;
      case 14:
        name+="MADMAN";
        break;
      case 15:
        name+="OBAMA";
        break;
      case 16:
        name+="666";
        break;
      case 17:
        name+="SANTA";
        break;
      case 18:
        name+="RETARD";
        break;
      case 19:
        name+="BANGER";
        break;
      case 20:
        name+="HEAD";
        break;
      case 21:
        name+="FINGER";
        break;
      case 22:
        name+="WIZZARD";
        break;
      case 23:
        name+="CHAD";
        break;
      case 24:
        name+="ANDY";
        break;
      case 25:
        name+="ARROW";
        break;
      case 26:
        name+="GAMER";
        break;
      case 27:
        name+="FART";
        break;
      case 28:
        name+="RACECAR";
        break;
      case 29:
        name+="LEGEND";
        break;
      case 31:
        name+="ASS";
        break;
      case 32:
        name+="ROCKET";
        break;
      case 33:
        name+="CHUNGUS";
        break;
      case 34:
        name+="HUNTER";
        break;
      case 35:
        name+="BULLET";
        break;
      case 36:
        name+="HACKER";
        break;
      case 37:
        name+="CLONE";
        break;
      case 38:
        name+="ASSASIN";
        break;
      case 39:
        name+="MOGUL";
        break;
      case 40:
        name+="BLOB";
        break;
      case 41:
        name+="X";
        break;
    }
}
  public void settings() {  fullScreen(P2D);  smooth(8); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "racing" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
